
mystring = "The quick, brown fox jumped over the lazy dog!"
mynumbers = [1,3,5,6,9,12,14,17,20,30]

# print(len(mystring))
# print(len(mynumbers))

# print(max(mystring))
# print(min(mynumbers))

prefix = "result: "
result = 5 

# # str can only be concatenate to str
# print(prefix + result)

# # str function typecast the numbers to string
# print(prefix + str(result))
# print(prefix + str(3.145))

# range(start, stop, step) - Stop point is not included
# for i in range(5, 15):
#     print(i)

# for i in range(5, 15, 2):
#     print(i)

# for i in range(5, len(mystring), 2):
#     print(mystring[i])

greeting = "Hello!"
count = 10
print(f"{greeting} you are visitor number {count}")