print("Hello World")
name = input("What is your name?")
print("Nice to meet you", name)