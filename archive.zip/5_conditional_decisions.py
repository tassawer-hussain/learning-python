x, y = 1000, 100

# if elif else
if x < y:
    print("x is less than y")
elif( x == y):
    print("x is equal to y")
else:
    print("x is greater than y")

# a if C else b
result = "x is less than y" if(x<y) else "x is greater or equal to y"
print(result)